package com.kosta.board.service;

import java.io.File;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletContext;
import javax.servlet.http.Part;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.kosta.board.dao.ArticleDao;
import com.kosta.board.dto.Article;
import com.kosta.board.util.PageInfo;

@Service
public class ArticleServiceImpl implements ArticleService {

	@Autowired
	private ArticleDao articleDao;

	@Autowired
	private ServletContext servletContext;

	@Override
	public Integer writeArticle(Article article, MultipartFile ifile, MultipartFile dfile) throws Exception {
		if (ifile != null && !ifile.isEmpty()) {

			final String IUPLOAD = servletContext.getInitParameter("iupload");
			File upFile = new File(IUPLOAD, ifile.getOriginalFilename());

			ifile.transferTo(upFile);
			article.setImageFilename(ifile.getOriginalFilename());
		}

		if (dfile != null && !dfile.isEmpty()) {
		    final String DUPLOAD = servletContext.getInitParameter("dupload");
		    File upFile = new File(DUPLOAD, dfile.getOriginalFilename());
		    dfile.transferTo(upFile);
		    article.setDownloadFilename(dfile.getOriginalFilename());
		}
		articleDao.insertArticle(article);
		return article.getNum();
	}

	@Override
	public Map<String, Object> detailArticle(Integer num) throws Exception {
		// TODO Auto-generated method stub
		return articleDao.selectArticleWithMember(num);
	}

	@Override
	public void deleteArticle(Integer num) throws Exception {
		// TODO Auto-generated method stub

	}

	@Override
	public void modifyArticle(Article article, String realPath, Part ifile, Part dfile) throws Exception {
		

	}

	@Override
	public List<Map<String, Object>> articleList(PageInfo pageInfo, String keyword, String type) throws Exception {
		Integer allCnt = articleDao.selectArticleWithMemberCnt(keyword, type);
		Integer allPage = (int)Math.ceil((double)allCnt/10);
		Integer startPage = (pageInfo.getCurPage()-1)/10*10+1;
		Integer endPage = startPage+10;
		if(endPage>allPage) endPage = allPage;
		
		pageInfo.setAllPage(allPage);
		pageInfo.setStartPage(startPage);
		pageInfo.setEndPage(endPage);
		
		Integer row = (pageInfo.getCurPage()-1)*10;

		return articleDao.selectArticleWithMemberList(keyword, type, row);
	}

	@Override
	public Boolean isHeart(Integer articleNum, String memberId) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Boolean toggleHeart(Integer articleNum, String memberId) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

}
