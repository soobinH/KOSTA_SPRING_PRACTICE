package com.kosta.board.service;

import java.io.File;

import javax.servlet.ServletContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.kosta.board.dao.MemberDao;
import com.kosta.board.dao.MemberDaoImpl;
import com.kosta.board.dto.Member;

@Service
public class MemberServiceImpl implements MemberService {
	
	@Autowired
	private MemberDao memberDao;
	
	@Autowired
	private ServletContext servletContext;
	
	public MemberServiceImpl() {
		memberDao = new MemberDaoImpl();
	}
	
	@Override
    public void join(Member member, MultipartFile profile) throws Exception {

		if (profile != null && !profile.isEmpty()) {

			final String IUPLOAD = servletContext.getInitParameter("iupload");
			File upFile = new File(IUPLOAD, profile.getOriginalFilename());

			profile.transferTo(upFile);
			member.setProfile(profile.getOriginalFilename());
		}
		
		memberDao.insertMember(member);
    }

	@Override
	public Member login(String id, String password) throws Exception {
		Member member = memberDao.selectMember(id);
		if(member==null) throw new Exception("아이디 오류");
		if(!member.getPassword().equals(password)) throw new Exception("비밀번호 오류");
		member.setPassword("");
		return member;
	}

	@Override
	public boolean checkMemberId(String id) throws Exception {
		return memberDao.selectMember(id)!=null;

	}

	@Override
	public void updatePassword(String id, String newPassword) throws Exception {
		// TODO Auto-generated method stub

	}

}
