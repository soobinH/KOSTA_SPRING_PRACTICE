package com.kosta.board.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.kosta.board.dto.Article;
import com.kosta.board.service.ArticleService;
import com.kosta.board.util.PageInfo;

@Controller
public class ArticleController {

	@Autowired
	private ArticleService articleService;
	
	
	@GetMapping("/article/write")
	//@RequestMapping(value="/article/write",Method=RequestMethod=GET)
	public String writeArticle() {
		return "article/writeform";
	//servlet-context �뿉�꽌 Prefix濡� /WEB-INF/views/ �씠�젃寃� �릺�뼱�엳�뼱�꽌 媛��뒫
	}
	
	@PostMapping("/article/write")
	public String writeArticle(Article article,@RequestParam(name="ifile",required=false)MultipartFile ifile,@RequestParam(name="dfile",required=false)MultipartFile dfile,Model model) {
		
		//�씠�윴�떇�쑝濡� �븯硫� �뙆�씪�쓣 臾댁“嫄� 媛��졇���빞�빐 
		//洹몃옒�꽌 �꼫�뒗 �꽑�깮�씠�빞 �씪怨� �쟻�뼱以섏빞�빐 @RequestParam(name="jsp�뿉 �옉�꽦�븳 name" required�뒗 default媛� TRUE�빞 洹몃옒�꽌 required=false�쟻�뼱以섏빞�븿) 
		
		
		System.out.println(article);
		try { 
			Integer num = articleService.writeArticle(article, ifile, dfile);
			return "redirect:/article/detail?num=" + num;
		}catch(Exception e){
			e.printStackTrace();
			model.addAttribute("err","寃뚯떆湲� �옉�꽦 �삤瑜�");
			return "error";
		}
		
		
	}
		
		@GetMapping("/article/detail")
		//@RequestMapping(value="/article/write",Method=RequestMethod=GET)
		public ModelAndView detailArticle(@RequestParam("num")Integer num) {
			ModelAndView mav = new ModelAndView();
			try {
				Map<String,Object> article = articleService.detailArticle(num);
				mav.addObject("article" ,article);
				mav.setViewName("article/boarddetail");
				
			}catch(Exception e) {
				e.printStackTrace();
				mav.addObject("err" ,"寃뚯떆湲� �긽�꽭 議고쉶 �삤瑜�");
				mav.setViewName("error");
				
			}
			return mav;
		

	}
		
	@GetMapping("/article/list")
	public ModelAndView articleList(@RequestParam(name="page", defaultValue="1") Integer page,
			@RequestParam(name="type", required=false) String type, @RequestParam(name="keyword", required=false) String keyword) {
		
		ModelAndView mav = new ModelAndView();
		PageInfo pageInfo = new PageInfo(page);
		try {
			mav.addObject("articleList", articleService.articleList(pageInfo, keyword, type));
			mav.addObject("pageInfo",pageInfo);
			mav.addObject("type",type);
			mav.addObject("keyword",keyword);
			mav.setViewName("article/boardlist");
		} catch(Exception e) {
			mav.addObject("err", "게시글 목록 조회 오류");
			mav.setViewName("common/error");
		}
		
		return mav;
	}
	
	
	

	
}
